#include "fun.h"

void error(char* send_buf)
{
	strcpy(send_buf,"error");
}
